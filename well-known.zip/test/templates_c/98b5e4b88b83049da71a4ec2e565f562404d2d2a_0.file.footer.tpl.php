<?php /* Smarty version 3.1.27, created on 2022-08-07 09:15:39
         compiled from "templates\common\footer.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:59911098462ef669b8058b7_03093305%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '98b5e4b88b83049da71a4ec2e565f562404d2d2a' => 
    array (
      0 => 'templates\\common\\footer.tpl',
      1 => 1659853524,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '59911098462ef669b8058b7_03093305',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_62ef669b807261_87846189',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_62ef669b807261_87846189')) {
function content_62ef669b807261_87846189 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '59911098462ef669b8058b7_03093305';
?>
<!-- Start Footer Area -->
<footer class="footer1">
    <div class="footer-area">
        <div class="container">
            <div class="row">

                <div class="col-xl-4 col-lg-4 col-md-4">
                    <div class="footer-content">
                        <div class="footer-head">
                            <h4>Invest plan</h4>
                            <ul class="footer-list">
                                <li><a href="#">Silver plan</a></li>
                                <li><a href="#">Gold plan</a></li>
                                <li><a href="#">Platinum Plan</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- end single footer -->
                <div class="col-xl-4 col-lg-4 col-md-4">
                    <div class="footer-content rs-mar-0">
                        <div class="footer-head">
                            <h4>Accounts</h4>
                            <ul class="footer-list">
                                <li><a href="#">Signup</a></li>
                                <li><a href="#">Login</a></li>
                                <li><a href="#">Privacy</a></li>
                                <li><a href="#">Notification</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- end single footer -->
                <div class="col-xl-4 col-lg-4 col-md-4">
                    <div class="footer-content last-content rs-mar-0">
                        <div class="footer-head">
                            <h4>Support</h4>
                            <ul class="footer-list">
                                <li><a href="#">Customer Care</a></li>
                                <li><a href="#">Live chat</a></li>
                                <li><a href="#">Notification</a></li>
                                <li><a href="#">Reviews</a></li>
                                <li><a href="#">Terms & Condition</a></li>
                                <li><a href="#">Contact us </a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Start Footer Bottom Area -->
    <div class="footer-area-bottom">
        <div class="container">
            <div class="row">
                <div class="col-xl-6 col-lg-6 col-md-6">
                    <div class="copyright">
                        <p>
                            Copyright © 2022
                            <a href="#">Goldspotfx</a> All Rights Reserved
                        </p>
                    </div>
                </div>
                <div class="col-xl-6 col-lg-6 col-md-6">
                    <div class="footer-menu">
                        <ul>
                            <li><a href="#">About</a></li>
                            <li><a href="#">Terms & Condition</a></li>
                            <li><a href="#">Privacy</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Footer Bottom Area -->
</footer>

<!-- All JS here -->

<!-- modernizr JS -->
<?php echo '<script'; ?>
 src="js/vendor/modernizr-3.5.0.min.js"><?php echo '</script'; ?>
>
<!-- jquery latest version -->
<?php echo '<script'; ?>
 src="js/vendor/jquery-1.12.4.min.js"><?php echo '</script'; ?>
>
<!-- Poper js -->
<?php echo '<script'; ?>
 src="js/popper.min.js"><?php echo '</script'; ?>
>
<!-- bootstrap js -->
<?php echo '<script'; ?>
 src="js/bootstrap.min.js"><?php echo '</script'; ?>
>
<!-- owl.carousel js -->
<?php echo '<script'; ?>
 src="js/owl.carousel.min.js"><?php echo '</script'; ?>
>
<!-- meanmenu js -->
<?php echo '<script'; ?>
 src="js/jquery.meanmenu.js"><?php echo '</script'; ?>
>
<!-- Counter js -->
<?php echo '<script'; ?>
 src="js/jquery.counterup.min.js"><?php echo '</script'; ?>
>
<!-- waypoint js -->
<?php echo '<script'; ?>
 src="js/waypoints.js"><?php echo '</script'; ?>
>
<!-- magnific js -->
<?php echo '<script'; ?>
 src="js/magnific.min.js"><?php echo '</script'; ?>
>
<!-- wow js -->
<?php echo '<script'; ?>
 src="js/wow.min.js"><?php echo '</script'; ?>
>
<!-- plugins js -->
<?php echo '<script'; ?>
 src="js/plugins.js"><?php echo '</script'; ?>
>
<!-- chart js -->
<?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/npm/chart.js"><?php echo '</script'; ?>
>
<!-- main js -->
<?php echo '<script'; ?>
 src="js/main.js"><?php echo '</script'; ?>
>
</body>

</html><?php }
}
?>