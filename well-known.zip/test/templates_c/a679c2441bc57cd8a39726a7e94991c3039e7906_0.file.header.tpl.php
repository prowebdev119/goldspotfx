<?php /* Smarty version 3.1.27, created on 2022-08-07 08:30:08
         compiled from "templates/common/header.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:33567066262efb05009f972_42373623%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a679c2441bc57cd8a39726a7e94991c3039e7906' => 
    array (
      0 => 'templates/common/header.tpl',
      1 => 1659874364,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '33567066262efb05009f972_42373623',
  'variables' => 
  array (
    'PAGE_TITLE' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_62efb0500a6274_50813930',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_62efb0500a6274_50813930')) {
function content_62efb0500a6274_50813930 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '33567066262efb05009f972_42373623';
?>
<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title><?php echo $_smarty_tpl->tpl_vars['PAGE_TITLE']->value;?>
</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- favicon.png and root directory -->
    <link rel="shortcut icon" type="image/x-icon" href="img/logo/favicon.ico">

    <!-- All css here -->

    <!-- bootstrap 4.0 css -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- owl.carousel css -->
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <!-- Animate css -->
    <link rel="stylesheet" href="css/animate.min.css">
    <!-- magnific css -->
    <link rel="stylesheet" href="css/magnific-popup.css">
    <!-- meanmenu css -->
    <link rel="stylesheet" href="css/meanmenu.min.css">
    <!-- Icon font css -->
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/themify-icons.css">
    <link rel="stylesheet" href="css/flaticon.css">
    <!-- style css -->
    <link rel="stylesheet" href="style.css">
    <!-- responsive css -->
    <link rel="stylesheet" href="css/responsive.css">
</head><?php }
}
?>