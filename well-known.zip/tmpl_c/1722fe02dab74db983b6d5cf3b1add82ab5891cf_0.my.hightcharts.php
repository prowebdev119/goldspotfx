<?php /* Smarty version 3.1.27, created on 2022-08-12 07:53:30
         compiled from "my:hightcharts" */ ?>
<?php
/*%%SmartyHeaderCode:25747120862f63f3a990912_05842896%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1722fe02dab74db983b6d5cf3b1add82ab5891cf' => 
    array (
      0 => 'my:hightcharts',
      1 => 1660305210,
      2 => 'my',
    ),
  ),
  'nocache_hash' => '25747120862f63f3a990912_05842896',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_62f63f3a991647_76742140',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_62f63f3a991647_76742140')) {
function content_62f63f3a991647_76742140 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '25747120862f63f3a990912_05842896';
?>
 <?php }
}
?>