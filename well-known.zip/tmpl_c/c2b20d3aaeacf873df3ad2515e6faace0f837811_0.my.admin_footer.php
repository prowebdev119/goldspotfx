<?php /* Smarty version 3.1.27, created on 2022-08-12 08:10:02
         compiled from "my:admin_footer" */ ?>
<?php
/*%%SmartyHeaderCode:25232143262f6431a89d741_01416168%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c2b20d3aaeacf873df3ad2515e6faace0f837811' => 
    array (
      0 => 'my:admin_footer',
      1 => 1660306202,
      2 => 'my',
    ),
  ),
  'nocache_hash' => '25232143262f6431a89d741_01416168',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_62f6431a89eb93_56001424',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_62f6431a89eb93_56001424')) {
function content_62f6431a89eb93_56001424 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '25232143262f6431a89d741_01416168';
?>
 </td> </tr> </table> <!-- Main: END --> 
 </td> </tr> </table> </td> </tr> </table> </td> </tr> <tr> <td height="19" bgcolor="ff8d00"><div align="center" class="forCopyright">Powered with HYIP Manager. <a href=http://www.goldcoders.com class="forCopyright">GoldCoders.com</a></div></td> 
 </tr> </table> </center></body> </html> <?php }
}
?>