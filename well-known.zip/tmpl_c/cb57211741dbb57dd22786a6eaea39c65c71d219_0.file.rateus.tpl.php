<?php /* Smarty version 3.1.27, created on 2022-08-09 08:20:25
         compiled from "/home/goldainy/public_html/tmpl/custom/rateus.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:74896554362f2510998fad0_43210367%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'cb57211741dbb57dd22786a6eaea39c65c71d219' => 
    array (
      0 => '/home/goldainy/public_html/tmpl/custom/rateus.tpl',
      1 => 1660045180,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '74896554362f2510998fad0_43210367',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_62f251099a3889_44291869',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_62f251099a3889_44291869')) {
function content_62f251099a3889_44291869 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '74896554362f2510998fad0_43210367';
echo $_smarty_tpl->getSubTemplate ("logo.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>
 
    


<section class="main-page">
        <div class="main-page-img"></div>
        <div class="main-inset">
            <div class="container">

                <div class="row">
                    <div class="col-md-12">
                        <div class="title">
                            <i></i>
                            <span>[  Rateus  ]</b></span>
                        </div>
                        <div class="main-page-content">
                            <div class="row">
                                <div class="col-md-12">
    

<table class="table rateus" width="100%">
    <tbody>
  
<tr>
            <td>Monitor Button</td>
            <td>Monitor Button</td>
            <td>Monitor Button</td>
            <td>Monitor Button</td>
        </tr>
<tr>
            <td>Monitor Button</td>
            <td>Monitor Button</td>
            <td>Monitor Button</td>
            <td>Monitor Button</td>
        </tr>

<tr>
            <td>Monitor Button</td>
            <td>Monitor Button</td>
            <td>Monitor Button</td>
            <td>Monitor Button</td>
        </tr>

<tr>
            <td>Monitor Button</td>
            <td>Monitor Button</td>
            <td>Monitor Button</td>
            <td>Monitor Button</td>
        </tr>
    </tbody>
</table>

    
    </div>
    </div>
</div>
</div>
</div>
</div>
</div>
</section>
<?php echo $_smarty_tpl->getSubTemplate ("footer2.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>
 <?php }
}
?>