<?php /* Smarty version 3.1.27, created on 2022-08-12 08:10:02
         compiled from "my:start_info_table" */ ?>
<?php
/*%%SmartyHeaderCode:207640536362f6431a894966_52058262%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f3ee3a3066c8206b176aa7471c3365b02260e5e4' => 
    array (
      0 => 'my:start_info_table',
      1 => 1660306202,
      2 => 'my',
    ),
  ),
  'nocache_hash' => '207640536362f6431a894966_52058262',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_62f6431a895744_72130042',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_62f6431a895744_72130042')) {
function content_62f6431a895744_72130042 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '207640536362f6431a894966_52058262';
?>
<div class="alert alert-warning"><?php }
}
?>