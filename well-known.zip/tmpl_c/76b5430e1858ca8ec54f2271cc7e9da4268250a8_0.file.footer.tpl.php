<?php /* Smarty version 3.1.27, created on 2022-08-12 05:05:28
         compiled from "/home/goldainy/public_html/tmpl/footer.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:205720671362f617d806efa0_59097406%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '76b5430e1858ca8ec54f2271cc7e9da4268250a8' => 
    array (
      0 => '/home/goldainy/public_html/tmpl/footer.tpl',
      1 => 1660045179,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '205720671362f617d806efa0_59097406',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_62f617d8072e71_02924462',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_62f617d8072e71_02924462')) {
function content_62f617d8072e71_02924462 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '205720671362f617d806efa0_59097406';
?>
 </div>
    </div>
</div>
</div>
</div>
</div>
</div>
</section>
<?php echo $_smarty_tpl->getSubTemplate ("footer2.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>