<?php /* Smarty version 3.1.27, created on 2022-08-12 08:04:27
         compiled from "/home/goldainy/public_html/tmpl/footer2.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:120918802862f641cb99f700_84517475%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c00a4f5f6e1269a82bbf42d0cc4c847c8ace8fe3' => 
    array (
      0 => '/home/goldainy/public_html/tmpl/footer2.tpl',
      1 => 1660067699,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '120918802862f641cb99f700_84517475',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_62f641cb9a0599_98994201',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_62f641cb9a0599_98994201')) {
function content_62f641cb9a0599_98994201 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '120918802862f641cb99f700_84517475';
?>
<section class="footer footer-page">
<?php }
}
?>