<?php /* Smarty version 3.1.27, created on 2022-08-12 08:03:27
         compiled from "/home/goldainy/public_html/tmpl/mfooter.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:130985176662f6418fa60080_02599828%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9485e25143d71077397e90e8274e360a77d57c83' => 
    array (
      0 => '/home/goldainy/public_html/tmpl/mfooter.tpl',
      1 => 1660045179,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '130985176662f6418fa60080_02599828',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_62f6418fa61009_88094629',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_62f6418fa61009_88094629')) {
function content_62f6418fa61009_88094629 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '130985176662f6418fa60080_02599828';
?>
</div>
        </div>
    </div>
    </div>
    </section>

</div>


</body>
</html><?php }
}
?>