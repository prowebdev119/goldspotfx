$( window ).resize(function() {
	//var size = $(window).height()-150;
	//$('.main-account').css({'min-height':size+'px'});
});

$(window).on('load', function () {
	//var size = $(window).height()-150;
	//$('.main-account').css({'min-height':size+'px'});
});


$(function(){
  

});

